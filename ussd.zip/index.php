<?php 
	ini_set('display_errors',1); 
 	error_reporting(E_ALL);	
?>
<?php
	/*$input = json_decode(file_get_contents('php://input'), true);
	include('recall.php');
	*/
	include('SampleUssdApp.php');
?>
